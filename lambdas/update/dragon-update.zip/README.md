# dragon-Read

a restfull GET route function for AWS lambda service

## created by: Matt Ravenmoore
